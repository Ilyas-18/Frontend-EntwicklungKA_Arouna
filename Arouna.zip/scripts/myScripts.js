let fahrtkostenberechnung=function () {
    let wert1 = 0
    wert1.getelementbyId

}
